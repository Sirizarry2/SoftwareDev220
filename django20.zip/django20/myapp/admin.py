from django.contrib import admin
from .models import ToDoItem

# Register your models here.
admin.site.register(ToDoItem)