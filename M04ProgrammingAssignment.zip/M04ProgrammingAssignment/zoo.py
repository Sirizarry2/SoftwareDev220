def hours():
    print("Open 9-5 daily")
