##11.2

import zoo as menagerie

print(menagerie.hours)