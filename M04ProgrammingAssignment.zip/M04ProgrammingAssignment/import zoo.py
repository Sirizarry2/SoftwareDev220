##11.1 continued

import zoo

print(zoo.hours)